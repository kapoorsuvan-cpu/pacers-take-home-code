"""Collect chart inputs from the calculated tables; official/current facts are sourced separately."""
import json
from pathlib import Path
import pandas as pd
b=Path(__file__).parent;r=b/'results'
t=pd.read_csv(r/'regular_team_metrics.csv').set_index('TEAM').loc['IND']
z=pd.read_csv(r/'regular_shots_opponent.csv');rim=z[z.SHOT_ZONE_BASIC.eq('Restricted Area')].set_index('OPPONENT');rank=int(rim.share.rank()['IND']);rim_pctile=(30-rank)/29*100
spl={s:pd.read_csv(r/f'{s}_possession_splits.csv') for s in ['regular','playoffs']}
def sp(s,split,side='off'):
 return spl[s].query("team=='IND' & scope=='all_minutes' & side==@side & split==@split").iloc[0].to_dict()
d={'baseline':{'names':['Ball security','Shooting efficiency','Offensive rating','Defensive rating','Offensive rebounding','Rim access prevented','Quick attacks prevented'],'percentiles':[t.tov_per100_pctile,t.efg_pctile,100*(30-9)/29,100*(30-14)/29,t.oreb_pct_pctile,rim_pctile,100]},'possession_chart':{'categories':['Quick live-ball attacks','After opponent makes'],'regular':[sp('regular','quick_live_7s')['ppp']*100,sp('regular','after_make')['ppp']*100],'playoffs':[sp('playoffs','quick_live_7s')['ppp']*100,sp('playoffs','after_make')['ppp']*100]},'deep':json.load(open(r/'deep_findings.json')),'onoff':{s:pd.read_csv(r/f'{s}_onoff.csv').to_dict('records') for s in ['regular','playoffs']}}
c=pd.read_csv(r/'regular_hauser_shot_context.csv');c=c[c.lineup_valid & c.SHOT_ZONE_BASIC.str.contains('3')].groupby('tatum_on')[['attempts','makes']].sum();d['hauser_no_tatum']={'makes':int(c.loc[False,'makes']),'attempts':int(c.loc[False,'attempts']),'pct':100*c.loc[False,'makes']/c.loc[False,'attempts']}
d['external_facts']={'regular_nba_offrtg':115.4,'regular_nba_defrtg':113.3,'regular_nba_pace':100.76,'regular_rank_off':9,'regular_rank_def':14,'regular_rank_pace':7,'playoff_nba_offrtg':114.8,'playoff_nba_defrtg':112.7,'playoff_nba_pace':98.52,'hauser_salary_2026':10848215,'dunn_salary_2026':5684800,'strus_salary_2026':16660836,'cap_2026':164961000,'hauser_2025_26_three_pct':39.3,'hauser_2025_26_3pa_per_game':6.5}
(b/'deck_data.json').write_text(json.dumps(d,indent=2))
