// Requires the Codex bundled @oai/artifact-tool JavaScript runtime.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Presentation,PresentationFile} from '@oai/artifact-tool';
const here=path.dirname(fileURLToPath(import.meta.url));
const out=process.env.PACERS_BUILD_DIR||path.join(here,'build');await fs.mkdir(out,{recursive:true});
const d=JSON.parse(await fs.readFile(path.join(here,'deck_data.json'),'utf8'));
const p=Presentation.create({slideSize:{width:1280,height:720}});
const C={navy:'#002D62',gold:'#FDBB30',ink:'#132C46',muted:'#526376',gray:'#DFE5EB',red:'#B34D36',white:'#FFFFFF'};
const font='Aptos';
const skill=process.env.PRESENTATIONS_SKILL_DIR||'/Users/suvankapoor/.codex/plugins/cache/openai-primary-runtime/presentations/26.909.12148/skills/presentations';
const {makeNativeBulletParagraphs}=await import(path.join(skill,'container_tools/artifact_tool_utils.mjs'));
const research=JSON.parse(await fs.readFile(path.join(here,'speaker_research.json'),'utf8'));
function bullets(s,items,x,y,w,h){const t=text(s,'',x,y,w,h,23);t.text=makeNativeBulletParagraphs(items,{marginLeftPoints:14,hangingPoints:8,spaceAfterPoints:15});return t;}
const text=(s,str,x,y,w,h,size=24,bold=false,color=C.ink)=>{const t=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});t.text=str;t.text.style={typeface:font,fontSize:size,bold,color,autoFit:'none',wrap:'square',insets:{top:0,left:0,right:0,bottom:0}};return t;};
function page(title,sub,num){const s=p.slides.add();s.background.fill=C.white;text(s,title,44,30,1190,60,39,true,C.navy);text(s,sub,46,98,1185,48,21,false,C.muted);text(s,String(num).padStart(2,'0'),1195,672,40,25,17,true,C.navy);return s;}
function footer(s,str){text(s,str,46,661,1130,48,13,false,C.muted);}
function notes(s,body,urls){s.speakerNotes.textFrame.setText(body+'\n\nSources (accessed October 6, 2026):\n'+urls.join('\n'));}
function chart(s,{x,y,w,h,categories,series,horizontal=false,max=100,format='0',legend=false}){return s.charts.add('bar',{position:{left:x,top:y,width:w,height:h},categories,series:series.map((a,i)=>({name:a.name,values:a.values,fill:a.color||[C.navy,C.gold][i],valuesFormatCode:format})),barOptions:{direction:horizontal?'bar':'column',grouping:'clustered',gapWidth:70},hasLegend:legend,legend:{position:'bottom',textStyle:{typeface:font,fontSize:18,fill:C.ink}},xAxis:{visible:true,textStyle:{typeface:font,fontSize:18,fill:C.ink},line:{fill:C.gray,width:1},majorGridlines:null,...(horizontal?{min:0,max,majorUnit:25,numberFormatCode:format}:{})},yAxis:{visible:true,textStyle:{typeface:font,fontSize:18,fill:C.ink},line:{fill:'none',width:0},majorGridlines:{fill:C.gray,width:.7},...(!horizontal?{min:0,max,majorUnit:max===180?30:max===60?20:25,numberFormatCode:format}:{})},dataLabels:{showValue:true,position:'outEnd',textStyle:{typeface:font,fontSize:20,bold:true,fill:C.ink}},chartFill:'none',chartLine:{fill:'none',width:0},plotAreaFill:'none',plotAreaLine:{fill:'none',width:0}});}
function table(s,values,x,y,w,h,widths,size=22){const tb=s.tables.add({rows:values.length,columns:values[0].length,left:x,top:y,width:w,height:h,values,columnWidths:widths});tb.borders.assign({fill:C.gray,width:.6,style:'solid'});for(let r=0;r<values.length;r++)for(let c=0;c<values[0].length;c++){const cell=tb.getCell(r,c);cell.fill=r===0?C.navy:C.white;cell.text.style={typeface:font,fontSize:r===0?size-1:size,bold:r===0||c===0,color:r===0?C.white:C.ink,verticalAlignment:'middle',insets:{top:10,bottom:10,left:14,right:14}};}return tb;}
const repo='https://github.com/shufinskiy/nba_data/tree/e829d4678be1e075f99e5d41a1c5f97089be446b';
const nbaRS='https://www.nba.com/stats/teams/advanced?Season=2024-25&SeasonType=Regular+Season';
const nbaPO='https://www.nba.com/stats/teams/advanced?Season=2024-25&SeasonType=Playoffs';
const recap='https://www.nbcsports.com/fantasy/basketball/news/indiana-pacers-2024-2025-fantasy-basketball-season-recap-what-the-hali';
// 1. Team expectations
{
const s=page('Team expectations: 45 wins in 2026–27','Base case: 45–37, roughly fifth to seventh in the East. Competitive first round, with Round 2 upside.',1);
chart(s,{x:45,y:180,w:640,h:362,categories:['Downside','Base','Upside'],series:[{name:'Projected wins',values:[37,45,51],color:C.gold}],max:60});
text(s,'Assumed net rating:   −2.0          +2.0          +4.5',65,555,660,31,21,false,C.muted);
text(s,'A strong baseline, a different roster',755,169,480,66,27,true,C.navy);
text(s,'2024–25: 50–32, then 15–8 in the playoffs. NBA ratings: 115.4 offense (9th), 113.3 defense (14th).',755,255,474,111,25);
text(s,'Zubac improves the glass: 3.7 offensive rebounds/game vs. Turner’s 1.3. Spacing is the trade-off.',755,393,474,107,25);
text(s,'Base assumes Haliburton plays about 65–70 games with useful creation. Health drives the range.',755,524,474,100,24);
text(s,'The 50-win baseline maps to 46.6 wins from net rating. A repeat Finals run is an upside case.',46,612,1186,32,22,true,C.navy);
footer(s,'Analyst scenarios, not a betting line. Wins ≈ 40.99 + 2.17 × net rating, fitted to 30 teams in 2024–25. The 37–51 range is not a confidence interval.');
notes(s,research[2].body+'\nOfficial regular-season ratings:115.4/113.3. Regular2024–25 pace100.76 ranks7th. Full postseason15–8. Starting-center rebounds compare2024–25 player totals, not future projections.',[repo,nbaRS,nbaPO,recap,'https://www.nba.com/news/2026-27-season-preview-ind','https://www.nba.com/clippers/news/clippers-acquire-mathurin-jackson-and-two-first-round-picks-from-indiana']);
}
// 2. Team strengths and weaknesses
{
const s=page('Team strengths and weaknesses','2024–25 baseline: fast pace, efficient shooting and ball security. Rebounding and rim access need work.',2);
chart(s,{x:35,y:165,w:710,h:385,categories:['Ball security','Shooting efficiency','Offensive rebounding','Rim access prevented','Quick attacks prevented'],series:[{name:'Favorable percentile',values:[93,90,3,28,100]}],horizontal:true,max:110});
text(s,'Favorable percentiles among 30 teams',58,559,670,30,21,false,C.muted);
text(s,'The playoff stress test',785,164,446,34,27,true,C.navy);
table(s,[['Offense','East rounds','Finals'],['Points / 100','119.3','109.2'],['Turnovers','12.7%','18.6%']],785,213,445,188,[181,132,132],22);
text(s,'Quick attacks still scored 150.2 points per 100 in the playoffs. After opponent makes: 108.9.',785,429,445,98,24);
text(s,'Haliburton on/off playoff offense: 120.5 / 106.0.* Creation depth matters under pressure.',785,553,445,80,23);
text(s,'56.2% eFG (4th). 21.3% OREB (29th). Opponents took 30.1% of shots at the rim (22nd in prevention).',46,605,704,48,21,true,C.navy);
footer(s,'Repository PBP calculations. Quick = live-ball start, ≤7 seconds, no OREB. OREB excludes team rebounds. *Unadjusted, 1,470 / 604 possessions. Details in notes.');
notes(s,research[0].body+'\n\n'+research[1].body+'\nPerimeter containment is a scouting interpretation of excessive rim access; shot-location counts alone cannot isolate the responsible defender or scheme. Indiana was seventh in official pace, not the league’s fastest team.',[repo,nbaRS,nbaPO,recap]);
}
// 3. Wing trade options: exactly three native bullets per player.
{
const s=page('Trade targets: perimeter defense and shooting','Indiana’s 22nd-ranked rim-access prevention points to a need for stronger perimeter containment.',3);
text(s,'Matisse Thybulle',46,166,560,42,31,true,C.navy);text(s,'Los Angeles Lakers',46,211,560,30,20,false,C.muted);
bullets(s,[
'Elite turnover creator: 2.2 steals/game in 2024–25. His 5.3 deflections per 36 led the NBA in 2023–24. Disruption can feed Indiana’s efficient quick offense.',
'Improved shooting: 43.8% from three, up from 34.6% in 2023–24. But 21/48 in only 15 games is a small sample. Use him for disruption without assuming every drive is contained.',
'2026–27 salary: $3.29M ($2.45M cap hit). Estimated cost: expendable bench player + one second, potentially two. Cheap specialist, with availability risk.'
],46,260,560,363);
text(s,'Royce O’Neale',672,166,561,42,31,true,C.navy);text(s,'Charlotte Hornets',672,211,561,30,20,false,C.muted);
bullets(s,[
'Adds strength and positional versatility against wings, reducing the burden on Indiana’s guards. His 3.9 defensive rebounds/game can help finish stops. Best balanced fit of these four.',
'40.6% from three on 441 attempts and 2.51 assists per turnover in 2024–25. Keeps Haliburton–Zubac actions spaced and the ball moving while adding defensive options.',
'2026–27 salary: $10.88M. Estimated cost: matching bench rotation player + two seconds, or a modest prospect + a second. Avoid a valuable first for a 33-year-old role player.'
],672,260,561,363);
footer(s,'2024–25 statistics unless marked. Sources: repository, NBA player bio, SalarySwish. Trade prices are analyst estimates, not reported asks. No package is cap-validated.');
notes(s,`Both wings address perimeter defense, but turnover creation is not synonymous with staying in front of a ball handler. Thybulle:33 steals/15games=2.2,21/48threes=43.75%,9blocks. His NBA bio lists5.3 deflections/36 and34.6%3P in2023–24. The recent shooting rise is encouraging but small; his2024–25 sample is only312minutes. Deflections are tracking data outside this repository and are not independently reconstructed. Royce2024–25:179/441threes=40.59%,163assists/65turnovers=2.51,296defensive rebounds/75observed games=3.95. His defensive versatility is a scouting judgment supported by Phoenix's acquisition statement, not a player-specific containment statistic. Current teams and salaries reflectOctober6,2026:ThybulleLAL3,286,399 salary/2,449,421 cap;O'NealeCHA10,875,000. The lower cap hit reflects the veteran-minimum subsidy, not lower player pay. Estimate ranges assume neutral matching salary; unwanted multiyear salary would raise the pick cost. Availability and salary/apron/eligibility rules require checking at the actual trade date. Priority is Royce for a regular rotation role; Thybulle for low-cost disruption. Neither fixes all self-creation limitations.`,[repo,'https://www.nba.com/player/1629680/matisse-thybulle/bio','https://www.salaryswish.com/players/matisse-thybulle','https://www.salaryswish.com/players/royce-oneale','https://www.nba.com/suns/news/suns-acquire-royce-oneale-and-david-roddy-in-three-team-trade-with-brooklyn-and-memphis','https://www.nba.com/hornets/news/charlotte-hornets-acquire-allen-oneale-first-round-pick']);
}
// 4. Backup center trade options: exactly three native bullets per player.
{
const s=page('Trade targets: mobile bigs for a faster bench','Seventh in pace in 2024–25. A rim runner adds an athletic change of pace beside Zubac and Huff.',4);
text(s,'Jaxson Hayes',46,166,560,42,31,true,C.navy);text(s,'Utah Jazz',46,211,560,30,20,false,C.muted);
bullets(s,[
'Runs the floor and rolls hard to the rim. Pick-and-roll vertical spacing gives Haliburton a lob target and a faster option alongside Zubac’s interior game and Huff’s stretch role.',
'Finished 80.6% at the rim (145/180) in 2024–25. His 86% assisted-make rate fits a playmaking guard. Adds 1.4 OREB/game, but offers little shooting or self-creation.',
'2026–27 salary: $6.00M. Estimated cost: expendable matching bench salary + one second, with two as the ceiling. Preferred budget big if the wing need is already covered.'
],46,260,560,363);
text(s,'Robert Williams III',672,166,561,42,31,true,C.navy);text(s,'Portland Trail Blazers',672,211,561,30,20,false,C.muted);
bullets(s,[
'When healthy, runs the floor, finishes lobs and supplies vertical spacing in pick-and-roll. Gives the second unit a mobile rim protector and a different look from Zubac and Huff.',
'5.9 rebounds, 1.8 offensive rebounds and 1.7 blocks/game in 2024–25. Targets Indiana’s weak second-chance production and adds help at the rim, but he played only 20 games.',
'2026–27 salary: about $14.0M. Estimated cost: matching bench salary + two seconds. A healthy market could demand a protected first; Indiana should pass at that price.'
],672,260,561,363);
footer(s,'Stats: 2024–25 repository PBP. Salaries: SalarySwish. Trade prices are estimates. Mobility describes role and scouting fit; no player-speed tracking was measured.');
notes(s,`Hayes2024–25:56games,145/180restricted-area makes=80.56%,161/223overallFG,85.71%allmadeFGassisted,78OREB/56=1.39. Williams20games,118rebounds/20=5.9,35OREB/20=1.75,33blocks/20=1.65,45/60restricted-area=75%. Both are projected lob/roll and early-offense finishers; restricted-area efficiency is NOT Synergy pick-and-roll PPP or tracking evidence of speed. Indiana seventh in pace favors mobile bench bigs, while Zubac provides interior strength and rebounding and Huff provides stretch shooting. Do not call either current center useless or infer mobility solely from height. Williams carries more rim-protection upside, health uncertainty and salary burden. Only one backup big is needed, and existing Nance minutes also matter. SalarySwish listsWilliams14,000,000; Basketball-Reference lists13,968,254. Both round to14.0M. Use rounded figure because public sources disagree slightly. SalarySwish extension total43.5M with19M initially guaranteed; do not use full nominal term as guaranteed liability. Hayes6M,currentUTA. Price estimates assume nonnegative matching salary and counterparty willingness. A protectedfirst forWilliams may be a seller's desired price after a healthy run, not an observed current offer. Recheck roster, trade eligibility, guarantees and matching/apron rules before any executable deal.`,[repo,'https://www.salaryswish.com/players/jaxson-hayes','https://www.salaryswish.com/players/robert-williamsiii','https://www.basketball-reference.com/contracts/players.html',nbaRS]);
}
// 5. Undervalued player with peers paid similar amounts.
{
const s=page('Undervalued player: Sam Hauser','A fit-based value pick: efficient shooting at a modest cap share, with limited creation and mixed on/off evidence.',5);
text(s,'$10.85M',46,164,615,62,45,true,C.navy);text(s,'6.6% of the 2026–27 cap. Signed through 2028–29.',46,231,630,57,23);
table(s,[['Player','2026–27 pay','2024–25 3P'],['Sam Hauser','$10.85M','41.6% / 399'],['Isaiah Joe','$11.32M','41.2% / 466'],['Sam Merrill','$9.16M','37.2% / 368'],['Aaron Nesmith','$11.00M','43.1% / 195']],46,311,641,281,[228,196,217],22);
text(s,'3P column shows percentage / attempts.',46,605,641,30,19,false,C.muted);
text(s,'91st percentile in 3P%',748,169,489,46,31,true,C.navy);
text(s,'Among 197 players with ≥200 attempts. Without Tatum: 39.2% on 186 validated attempts.',750,230,480,95,24);
text(s,'Contract value has limits',748,347,484,40,27,true,C.navy);
text(s,'4% cheaper than Joe for similar shooting. Costs 18% more than Merrill. Nesmith’s broader role makes him a strong counterexample.',750,404,480,114,24);
text(s,'95% of made threes were assisted. Only 11 FTA. Net on/off: −0.4 points/100. Useful specialist, not a proven impact outlier.',750,540,480,103,23);
footer(s,'Repository PBP and SalarySwish. Recent check: Hauser shot 39.3% in 2025–26. Peer comparison is descriptive, not a salary model. 2025 playoffs: only 7/21 threes.');
notes(s,research[4].body+`\nADDED CONTRACT PEERS:2026–27 salaries:Hauser10,848,215,IsaiahJoe11,323,006,SamMerrill9,160,715,AaronNesmith11,000,000.2024–25 shooting is repository-derived:Hauser166/39941.60%,Joe192/46641.20%,Merrill137/36837.23%,Nesmith84/19543.08%. Hauser4.19%cheaperthanJoe,18.42%morethanMerrill,1.38%cheaperthanNesmith. These are selected established non-rookie perimeter role players with salaries within roughly20% ofHauser, not a comprehensive matching algorithm. Shooting percentages do not control for shot difficulty, minutes, defense or creation. Nesmith carries a larger defensive role andJoe is similarly efficient, limiting any claim Hauser is uniquely underpaid. The undervaluation thesis rests on useful high-volume, low-touch spacing at6.6%cap and three remaining controlled seasons. His four-year45Mextension runs2025–26through2028–29, fullyguaranteed. A selected higher-price comparator,MaxStrus16.66M, belongs in supplemental notes rather than implying all similar players cost that much.`,[repo,'https://www.salaryswish.com/players/sam-hauser','https://www.salaryswish.com/players/isaiah-joe','https://www.salaryswish.com/players/sam-merrill','https://www.salaryswish.com/players/aaron-nesmith','https://www.salaryswish.com/players/max-strus','https://www.basketball-reference.com/players/h/hausesa01.html','https://www.nba.com/news/nba-salary-cap-2026-27-season']);
}
await (await PresentationFile.exportPptx(p)).save(path.join(out,'candidate.pptx'));
for(let i=0;i<p.slides.items.length;i++){const preview=await p.export({slide:p.slides.items[i],format:'png',scale:1});await fs.writeFile(path.join(out,`slide-${i+1}.png`),new Uint8Array(await preview.arrayBuffer()));}
console.log('Built',path.join(out,'candidate.pptx'));
