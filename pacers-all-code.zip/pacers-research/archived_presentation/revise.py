from pathlib import Path
import re
f=Path('outputs/pacers-research/build_deck.mjs');s=f.read_text();Path('work/pacers/build_old.mjs').write_text(s)
# Preserve full analytical speaker notes from the initial build.
blocks=re.findall(r'notes\(s,`(.*?)`,\[(.*?)\]\);',s,re.S)
import json
Path('outputs/pacers-research/speaker_research.json').write_text(json.dumps([{'body':a,'sources_js':b} for a,b in blocks],indent=2))
s=s[:s.index('// 1. Full-season')]
s=s.replace("const font='Aptos';", "const font='Aptos';\nconst skill=process.env.PRESENTATIONS_SKILL_DIR||'/Users/suvankapoor/.codex/plugins/cache/openai-primary-runtime/presentations/26.909.12148/skills/presentations';\nconst {makeNativeBulletParagraphs}=await import(path.join(skill,'container_tools/artifact_tool_utils.mjs'));\nconst research=JSON.parse(await fs.readFile(path.join(here,'speaker_research.json'),'utf8'));\nfunction bullets(s,items,x,y,w,h){const t=text(s,'',x,y,w,h,23);t.text=makeNativeBulletParagraphs(items,{marginLeftPoints:14,hangingPoints:8,spaceAfterPoints:15});return t;}")
f.write_text(s)
